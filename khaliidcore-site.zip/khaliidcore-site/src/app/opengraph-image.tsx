import { ImageResponse } from "next/og";
import { site } from "@/data/site";

export const alt = `${site.name} – ${site.displayName}`;
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export default function OpengraphImage() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          padding: 80,
          background: "radial-gradient(circle at 80% 20%, rgba(57,255,20,0.18), #050505 55%)",
          color: "#fff",
        }}
      >
        <div style={{ fontSize: 28, letterSpacing: 10, color: "#39ff14" }}>{site.displayName.toUpperCase()}</div>
        <div style={{ fontSize: 150, fontWeight: 800, letterSpacing: -6, marginTop: 16 }}>{site.name}</div>
        <div style={{ fontSize: 36, color: "rgba(255,255,255,0.6)", marginTop: 12 }}>{site.tagline}</div>
      </div>
    ),
    size,
  );
}
