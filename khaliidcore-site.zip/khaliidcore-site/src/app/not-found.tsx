import Link from "next/link";
import { ArrowLeft } from "lucide-react";

export const metadata = { title: "Page not found", robots: { index: false } };

export default function NotFound() {
  return (
    <section className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden px-6 text-center">
      <div className="grid-bg absolute inset-0" aria-hidden />
      <div className="absolute left-1/2 top-1/2 h-[40rem] w-[40rem] -translate-x-1/2 -translate-y-1/2 animate-drift rounded-full bg-accent/10 blur-[140px]" aria-hidden />
      <p className="relative font-display text-sm uppercase tracking-[0.4em] text-accent">Error 404</p>
      <h1 className="relative mt-4 font-display text-[28vw] font-bold leading-none tracking-tighter sm:text-[14rem]">
        4<span className="text-accent">0</span>4
      </h1>
      <p className="relative mt-4 max-w-md text-white/60">
        This page doesn&apos;t exist or has moved. Let&apos;s get you back to the work.
      </p>
      <Link href="/" className="btn-primary relative mt-10">
        <ArrowLeft size={16} aria-hidden /> Back to home
      </Link>
    </section>
  );
}
