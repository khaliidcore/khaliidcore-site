"use client";

import { Check } from "lucide-react";
import Section from "@/components/ui/Section";
import Reveal from "@/components/ui/Reveal";
import { services } from "@/data/content";

export default function Services() {
  return (
    <Section
      id="services"
      eyebrow="Services"
      title="What I can build with you."
      description="Services I offer, from a single edit to a full digital presence."
    >
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {services.map((s, i) => (
          <Reveal key={s.title} delay={(i % 3) * 0.08}>
            <article className="card group h-full p-6">
              <div
                className="pointer-events-none absolute -right-10 -top-10 h-32 w-32 rounded-full bg-accent/0 blur-3xl transition-colors duration-500 group-hover:bg-accent/20"
                aria-hidden
              />
              <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-white/10 bg-accent-soft text-accent">
                <s.icon size={22} aria-hidden />
              </div>
              <h3 className="mt-6 font-display text-xl font-semibold">{s.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-white/55">{s.description}</p>
              <ul className="mt-5 space-y-2 text-sm text-white/70">
                {s.points.map((p) => (
                  <li key={p} className="flex items-center gap-2">
                    <Check size={14} className="text-accent" aria-hidden /> {p}
                  </li>
                ))}
              </ul>
            </article>
          </Reveal>
        ))}
      </div>
    </Section>
  );
}
