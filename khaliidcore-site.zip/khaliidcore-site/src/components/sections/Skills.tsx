"use client";

import { motion } from "framer-motion";
import Section from "@/components/ui/Section";
import Reveal from "@/components/ui/Reveal";
import { skills, tools } from "@/data/content";

export default function Skills() {
  return (
    <Section
      id="skills"
      eyebrow="Skills & Technology"
      title="Craft, tools and tech."
      description="Editable skill cards. Adjust names, notes and levels in src/data/content.tsx."
    >
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {skills.map((s, i) => (
          <Reveal key={s.name} delay={(i % 3) * 0.08}>
            <div className="card h-full p-6">
              <div className="flex items-center justify-between">
                <s.icon size={22} className="text-accent" aria-hidden />
                <span className="font-display text-sm text-white/50">{s.level}%</span>
              </div>
              <h3 className="mt-5 font-display text-lg font-semibold">{s.name}</h3>
              <p className="mt-1 text-sm text-white/55">{s.note}</p>
              <div
                className="mt-5 h-1.5 overflow-hidden rounded-full bg-white/10"
                role="progressbar"
                aria-valuenow={s.level}
                aria-valuemin={0}
                aria-valuemax={100}
                aria-label={`${s.name} proficiency`}
              >
                <motion.div
                  className="h-full rounded-full bg-accent"
                  initial={{ width: 0 }}
                  whileInView={{ width: `${s.level}%` }}
                  viewport={{ once: true }}
                  transition={{ duration: 1.1, ease: "easeOut", delay: 0.2 }}
                />
              </div>
            </div>
          </Reveal>
        ))}
      </div>

      <Reveal className="mt-10">
        <p className="mb-4 text-xs uppercase tracking-[0.3em] text-white/40">Tools</p>
        <ul className="flex flex-wrap gap-2.5">
          {tools.map((t) => (
            <li key={t} className="rounded-full border border-white/10 bg-white/[0.03] px-4 py-2 text-sm text-white/70">
              {t}
            </li>
          ))}
        </ul>
      </Reveal>
    </Section>
  );
}
