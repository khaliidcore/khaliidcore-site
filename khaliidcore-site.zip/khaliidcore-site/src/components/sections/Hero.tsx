"use client";

import { motion, useReducedMotion } from "framer-motion";
import { ArrowDown, ArrowRight } from "lucide-react";
import { site } from "@/data/site";

const letters = site.name.split("");

export default function Hero() {
  const reduce = useReducedMotion();

  return (
    <section id="home" aria-label="Introduction" className="relative flex min-h-screen items-center justify-center overflow-hidden px-5 pb-16 pt-28 sm:px-8">
      {/* Background animation */}
      <div className="grid-bg absolute inset-0" aria-hidden />
      <div className="pointer-events-none absolute -left-32 top-1/4 h-[32rem] w-[32rem] animate-drift rounded-full bg-accent/15 blur-[140px]" aria-hidden />
      <div className="pointer-events-none absolute -right-40 bottom-0 h-[28rem] w-[28rem] animate-drift rounded-full bg-white/5 blur-[120px] [animation-delay:-9s]" aria-hidden />
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-ink to-transparent" aria-hidden />

      <div className="relative z-10 mx-auto max-w-5xl text-center">
        <motion.p
          initial={reduce ? false : { opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.7, duration: 0.6 }}
          className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.03] px-4 py-1.5 text-xs uppercase tracking-[0.3em] text-white/60"
        >
          <span className="h-1.5 w-1.5 rounded-full bg-accent" aria-hidden /> {site.tagline}
        </motion.p>

        <h1 className="mt-8 font-display text-[clamp(2.6rem,12.5vw,9rem)] font-bold leading-none tracking-tighter" aria-label={site.name}>
          {letters.map((l, i) => (
            <motion.span
              key={i}
              aria-hidden
              className={`inline-block ${i >= letters.length - 4 ? "text-accent" : ""}`}
              initial={reduce ? false : { opacity: 0, y: "60%", filter: "blur(10px)" }}
              animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
              transition={{ delay: 1.5 + i * 0.045, duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
            >
              {l}
            </motion.span>
          ))}
        </h1>

        <motion.div
          initial={reduce ? false : { opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 2.2, duration: 0.8 }}
        >
          <p className="mt-8 font-display text-xl text-white sm:text-2xl">Hi, I&apos;m {site.displayName}.</p>
          <p className="mx-auto mt-3 max-w-xl text-base leading-relaxed text-white/60 sm:text-lg">
            I create digital experiences through creativity, technology, and innovation.
          </p>
          <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
            <a href="#portfolio" className="btn-primary">
              Explore My Work <ArrowRight size={16} aria-hidden />
            </a>
            <a href="#contact" className="btn-ghost">
              Let&apos;s Connect
            </a>
          </div>
        </motion.div>
      </div>

      <a href="#about" aria-label="Scroll to About" className="absolute bottom-8 left-1/2 z-10 -translate-x-1/2 text-white/40 transition-colors hover:text-accent">
        <ArrowDown size={20} className="animate-bounce" />
      </a>
    </section>
  );
}
