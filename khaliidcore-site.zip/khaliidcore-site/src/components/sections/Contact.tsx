"use client";

import { useState } from "react";
import { Instagram, Youtube, Mail, MessageCircle, Send, CheckCircle2, AlertCircle } from "lucide-react";
import Section from "@/components/ui/Section";
import Reveal from "@/components/ui/Reveal";
import { site, isPlaceholderEmail, isPlaceholderWhatsapp } from "@/data/site";

type Status = "idle" | "sending" | "success" | "error";

const channels = [
  { label: "Instagram", value: "@khaliidcore", href: site.links.instagram, icon: Instagram, external: true },
  { label: "YouTube", value: "@khaliidcore", href: site.links.youtube, icon: Youtube, external: true },
  {
    label: "Email",
    value: isPlaceholderEmail ? "Add your email in site.ts" : site.links.email,
    href: `mailto:${site.links.email}`,
    icon: Mail,
    external: false,
  },
  {
    label: "WhatsApp",
    value: isPlaceholderWhatsapp ? "Add your number in site.ts" : `+${site.links.whatsapp}`,
    href: `https://wa.me/${site.links.whatsapp}`,
    icon: MessageCircle,
    external: true,
  },
];

export default function Contact() {
  const [status, setStatus] = useState<Status>("idle");
  const [message, setMessage] = useState("");

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const data = Object.fromEntries(new FormData(form).entries());
    setStatus("sending");
    setMessage("");
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const json = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) throw new Error(json.error ?? "Something went wrong. Please try again.");
      setStatus("success");
      setMessage("Thanks, your message has been sent. I'll get back to you soon.");
      form.reset();
    } catch (err) {
      setStatus("error");
      setMessage(err instanceof Error ? err.message : "Network error. Please try again.");
    }
  }

  const field =
    "w-full rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-white placeholder:text-white/30 transition-colors focus:border-accent focus:outline-none";

  return (
    <Section
      id="contact"
      eyebrow="Contact"
      title="Let's create something."
      description="Have a project, collaboration or question? Send a message or reach out on any channel."
    >
      <div className="grid gap-10 lg:grid-cols-[1fr_1.2fr]">
        <Reveal>
          <ul className="space-y-3">
            {channels.map((c) => (
              <li key={c.label}>
                <a
                  href={c.href}
                  {...(c.external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
                  className="card group flex items-center gap-4 p-4"
                >
                  <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-accent-soft text-accent">
                    <c.icon size={20} aria-hidden />
                  </span>
                  <span>
                    <span className="block text-sm font-medium">{c.label}</span>
                    <span className="block text-sm text-white/50">{c.value}</span>
                  </span>
                </a>
              </li>
            ))}
          </ul>
        </Reveal>

        <Reveal delay={0.1}>
          <form onSubmit={onSubmit} noValidate={false} className="card space-y-4 p-6 sm:p-8" aria-label="Contact form">
            {/* Honeypot: hidden from people, bots fill it */}
            <div className="absolute -left-[9999px]" aria-hidden>
              <label>
                Leave empty <input type="text" name="website" tabIndex={-1} autoComplete="off" />
              </label>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label htmlFor="name" className="mb-1.5 block text-sm text-white/70">Name</label>
                <input id="name" name="name" required minLength={2} maxLength={80} autoComplete="name" className={field} placeholder="Your name" />
              </div>
              <div>
                <label htmlFor="email" className="mb-1.5 block text-sm text-white/70">Email</label>
                <input id="email" name="email" type="email" required maxLength={120} autoComplete="email" className={field} placeholder="you@example.com" />
              </div>
            </div>
            <div>
              <label htmlFor="subject" className="mb-1.5 block text-sm text-white/70">Subject</label>
              <input id="subject" name="subject" maxLength={120} className={field} placeholder="What's this about?" />
            </div>
            <div>
              <label htmlFor="msg" className="mb-1.5 block text-sm text-white/70">Message</label>
              <textarea id="msg" name="message" required minLength={10} maxLength={3000} rows={5} className={`${field} resize-y`} placeholder="Tell me about your project..." />
            </div>

            <button type="submit" disabled={status === "sending"} className="btn-primary w-full disabled:opacity-60 sm:w-auto">
              {status === "sending" ? "Sending..." : "Send Message"} <Send size={16} aria-hidden />
            </button>

            <div aria-live="polite" role="status" className="min-h-6 text-sm">
              {status === "success" && (
                <p className="flex items-start gap-2 text-accent">
                  <CheckCircle2 size={18} className="mt-0.5 shrink-0" aria-hidden /> {message}
                </p>
              )}
              {status === "error" && (
                <p className="flex items-start gap-2 text-red-400">
                  <AlertCircle size={18} className="mt-0.5 shrink-0" aria-hidden />
                  <span>
                    {message}{" "}
                    {!isPlaceholderEmail && (
                      <a href={`mailto:${site.links.email}`} className="underline">Email me directly</a>
                    )}
                  </span>
                </p>
              )}
            </div>
          </form>
        </Reveal>
      </div>
    </Section>
  );
}
