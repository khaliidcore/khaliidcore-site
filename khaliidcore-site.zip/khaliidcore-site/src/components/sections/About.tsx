import Section from "@/components/ui/Section";
import Reveal from "@/components/ui/Reveal";
import { Lightbulb, Cpu, BookOpen, Film } from "lucide-react";

const pillars = [
  { icon: Lightbulb, title: "Creativity", text: "Every project starts with an idea worth telling well." },
  { icon: Film, title: "Digital Content", text: "Video and social content shaped for how people watch today." },
  { icon: Cpu, title: "Technology", text: "Modern tools and web technology to build and deliver the work." },
  { icon: BookOpen, title: "Continuous Learning", text: "Always refining craft, workflow and skill." },
];

export default function About() {
  return (
    <Section id="about" eyebrow="About" title="The person behind KHALIIDCORE.">
      <div className="grid gap-12 lg:grid-cols-[1.2fr_1fr]">
        <Reveal className="space-y-5 text-base leading-relaxed text-white/65 sm:text-lg">
          <p>
            I&apos;m <span className="text-white">Khalid Nadaf</span>, a video editor and content creator working under the name
            KHALIIDCORE. My focus is turning ideas into visual stories, from short-form reels to cinematic and long-form edits.
          </p>
          <p>
            I&apos;m interested in where creativity meets technology: how good storytelling, thoughtful design and modern tools
            can come together to make digital content that feels sharp and intentional.
          </p>
          <p>
            I treat learning as part of the work. Each project is a chance to improve my craft, try a new approach and
            deliver something better than the last.
          </p>
          {/* EDIT: add your location, story or personal details here */}
        </Reveal>

        <div className="grid gap-4 sm:grid-cols-2">
          {pillars.map((p, i) => (
            <Reveal key={p.title} delay={i * 0.08}>
              <div className="card h-full p-5">
                <p.icon className="text-accent" size={22} aria-hidden />
                <h3 className="mt-4 font-display text-lg font-semibold">{p.title}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-white/55">{p.text}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </Section>
  );
}
