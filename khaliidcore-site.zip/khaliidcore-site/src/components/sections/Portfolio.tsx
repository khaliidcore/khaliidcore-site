"use client";

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowUpRight, ImageIcon } from "lucide-react";
import Section from "@/components/ui/Section";
import { projectCategories, projects } from "@/data/content";

export default function Portfolio() {
  const [filter, setFilter] = useState<(typeof projectCategories)[number]>("All");
  const visible = filter === "All" ? projects : projects.filter((p) => p.category === filter);

  return (
    <Section
      id="portfolio"
      eyebrow="Portfolio"
      title="Selected work."
      description="Project gallery. Edit src/data/content.tsx to add your real projects, images and videos."
    >
      <div role="tablist" aria-label="Filter projects" className="mb-10 flex flex-wrap gap-2">
        {projectCategories.map((c) => (
          <button
            key={c}
            role="tab"
            aria-selected={filter === c}
            onClick={() => setFilter(c)}
            className={`rounded-full border px-4 py-2 text-sm transition-colors ${
              filter === c ? "border-accent bg-accent text-ink" : "border-white/15 text-white/65 hover:border-white/40 hover:text-white"
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      <motion.div layout className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        <AnimatePresence mode="popLayout">
          {visible.map((p) => (
            <motion.article
              layout
              key={p.title}
              initial={{ opacity: 0, scale: 0.94 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.94 }}
              transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
              whileHover={{ y: -6 }}
              className="card group flex flex-col"
            >
              <div className="relative aspect-video overflow-hidden bg-gradient-to-br from-white/[0.06] to-transparent">
                {p.video ? (
                  <video
                    src={p.video}
                    poster={p.image}
                    muted
                    loop
                    playsInline
                    preload="none"
                    onMouseEnter={(e) => e.currentTarget.play().catch(() => {})}
                    onMouseLeave={(e) => e.currentTarget.pause()}
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                ) : p.image ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={p.image} alt={p.title} loading="lazy" className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
                ) : (
                  <div className="flex h-full w-full flex-col items-center justify-center gap-2 text-white/30">
                    <ImageIcon size={28} aria-hidden />
                    <span className="text-xs uppercase tracking-widest">Preview placeholder</span>
                  </div>
                )}
                <span className="absolute left-3 top-3 rounded-full bg-ink/70 px-3 py-1 text-xs text-accent backdrop-blur">{p.category}</span>
              </div>
              <div className="flex flex-1 flex-col p-5">
                <h3 className="font-display text-lg font-semibold">{p.title}</h3>
                <p className="mt-2 flex-1 text-sm leading-relaxed text-white/55">{p.description}</p>
                <a
                  href={p.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-5 inline-flex items-center gap-1.5 text-sm font-medium text-accent transition-all group-hover:gap-3"
                >
                  View Project <ArrowUpRight size={16} aria-hidden />
                  <span className="sr-only"> – {p.title} (opens in a new tab)</span>
                </a>
              </div>
            </motion.article>
          ))}
        </AnimatePresence>
      </motion.div>

      {visible.length === 0 && <p className="text-white/50">No projects in this category yet.</p>}
    </Section>
  );
}
