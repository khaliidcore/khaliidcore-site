"use client";

import Section from "@/components/ui/Section";
import Reveal from "@/components/ui/Reveal";
import { milestones } from "@/data/content";

export default function Achievements() {
  return (
    <Section
      id="achievements"
      eyebrow="Milestones"
      title="Numbers that matter."
      description="Placeholders until real figures are added. Edit src/data/content.tsx."
    >
      <dl className="grid grid-cols-2 gap-5 lg:grid-cols-4">
        {milestones.map((m, i) => (
          <Reveal key={m.label} delay={i * 0.08}>
            <div className="card flex h-full flex-col p-6">
              <dt className="order-2 mt-3 font-medium">{m.label}</dt>
              <dd className="order-1 font-display text-5xl font-bold tracking-tight text-accent sm:text-6xl">{m.value}</dd>
              {m.placeholder && <p className="order-3 mt-1 text-xs text-white/40">{m.note}</p>}
            </div>
          </Reveal>
        ))}
      </dl>
    </Section>
  );
}
