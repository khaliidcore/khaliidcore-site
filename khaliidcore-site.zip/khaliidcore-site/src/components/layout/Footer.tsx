import { Instagram, Youtube } from "lucide-react";
import { site } from "@/data/site";

export default function Footer() {
  return (
    <footer className="border-t border-white/10 px-5 py-10 sm:px-8">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-6 sm:flex-row">
        <div className="text-center sm:text-left">
          <p className="font-display font-bold tracking-[0.2em]">
            KHALII<span className="text-accent">DCORE</span>
          </p>
          <p className="mt-1 text-sm text-white/50">{site.tagline}</p>
        </div>
        <div className="flex items-center gap-4">
          <a href={site.links.instagram} target="_blank" rel="noopener noreferrer" aria-label="Instagram" className="text-white/60 transition-colors hover:text-accent">
            <Instagram size={20} />
          </a>
          <a href={site.links.youtube} target="_blank" rel="noopener noreferrer" aria-label="YouTube" className="text-white/60 transition-colors hover:text-accent">
            <Youtube size={20} />
          </a>
        </div>
        <p className="text-xs text-white/40">
          © {new Date().getFullYear()} {site.displayName}. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
