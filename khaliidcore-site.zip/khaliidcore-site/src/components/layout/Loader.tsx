"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { site } from "@/data/site";

/** Brand loading animation. Shown once per browser session. */
export default function Loader() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    let seen = false;
    try {
      seen = sessionStorage.getItem("kc-loaded") === "1";
    } catch {
      /* storage unavailable: just show the loader */
    }
    if (seen) return;
    setVisible(true);
    document.documentElement.style.overflow = "hidden";
    const t = setTimeout(() => {
      setVisible(false);
      document.documentElement.style.overflow = "";
      try {
        sessionStorage.setItem("kc-loaded", "1");
      } catch {
        /* ignore */
      }
    }, 1600);
    return () => {
      clearTimeout(t);
      document.documentElement.style.overflow = "";
    };
  }, []);

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          key="loader"
          role="status"
          aria-live="polite"
          className="fixed inset-0 z-[90] flex flex-col items-center justify-center bg-ink"
          exit={{ opacity: 0, transition: { duration: 0.6 } }}
        >
          <motion.p
            initial={{ opacity: 0, letterSpacing: "0.1em" }}
            animate={{ opacity: 1, letterSpacing: "0.35em" }}
            transition={{ duration: 1.2, ease: "easeOut" }}
            className="font-display text-xl font-bold sm:text-3xl"
          >
            {site.name.slice(0, -4)}
            <span className="text-accent">{site.name.slice(-4)}</span>
          </motion.p>
          <div className="mt-8 h-px w-48 overflow-hidden bg-white/10">
            <motion.div
              className="h-full bg-accent"
              initial={{ width: "0%" }}
              animate={{ width: "100%" }}
              transition={{ duration: 1.4, ease: "easeInOut" }}
            />
          </div>
          <span className="sr-only">Loading {site.name}</span>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
