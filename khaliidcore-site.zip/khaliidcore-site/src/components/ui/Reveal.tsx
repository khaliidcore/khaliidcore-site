"use client";

import { motion, useReducedMotion } from "framer-motion";

type Props = { children: React.ReactNode; delay?: number; className?: string; y?: number };

/** Scroll-triggered fade/slide-in. Respects reduced motion. */
export default function Reveal({ children, delay = 0, className, y = 28 }: Props) {
  const reduce = useReducedMotion();
  return (
    <motion.div
      className={className}
      initial={reduce ? false : { opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.7, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
}
