import { site } from "@/data/site";

/** Person + WebSite structured data. Only verified facts are included. */
export default function JsonLd() {
  const data = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "WebSite",
        "@id": `${site.url}/#website`,
        url: site.url,
        name: site.name,
        alternateName: ["KHALIIDCORE Official Website", `${site.displayName} Portfolio`],
        description: site.description,
        inLanguage: "en",
        publisher: { "@id": `${site.url}/#person` },
      },
      {
        "@type": "Person",
        "@id": `${site.url}/#person`,
        name: site.displayName,
        alternateName: site.name,
        url: site.url,
        description: site.description,
        jobTitle: "Video Editor & Content Creator",
        sameAs: [site.links.instagram, site.links.youtube],
      },
    ],
  };
  return (
    <script
      type="application/ld+json"
      // eslint-disable-next-line react/no-danger
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data).replace(/</g, "\\u003c") }}
    />
  );
}
