import Reveal from "./Reveal";

type Props = { id: string; eyebrow: string; title: string; description?: string; children: React.ReactNode };

/** Consistent section wrapper + heading. */
export default function Section({ id, eyebrow, title, description, children }: Props) {
  return (
    <section id={id} aria-labelledby={`${id}-title`} className="relative px-5 py-24 sm:px-8 md:py-32">
      <div className="mx-auto max-w-6xl">
        <Reveal>
          <p className="font-display text-xs uppercase tracking-[0.35em] text-accent">{eyebrow}</p>
          <h2 id={`${id}-title`} className="mt-4 max-w-3xl font-display text-4xl font-bold leading-[1.05] tracking-tight sm:text-5xl md:text-6xl">
            {title}
          </h2>
          {description && <p className="mt-5 max-w-2xl text-base leading-relaxed text-white/60 sm:text-lg">{description}</p>}
        </Reveal>
        <div className="mt-14">{children}</div>
      </div>
    </section>
  );
}
