/**
 * SINGLE SOURCE OF TRUTH for brand, links and SEO.
 * Anything marked PLACEHOLDER must be replaced with your real details.
 */
export const site = {
  name: "KHALIIDCORE",
  displayName: "Khalid Nadaf",
  url: process.env.NEXT_PUBLIC_SITE_URL ?? "https://www.khaliidcore.com",
  tagline: "Creativity Beyond Limits.",
  title: "KHALIIDCORE | Khalid Nadaf – Official Website & Portfolio",
  description:
    "KHALIIDCORE is the official website and creative portfolio of Khalid Nadaf: video editing, content creation, design and digital storytelling.",
  keywords: [
    "Khalid Nadaf",
    "KHALIIDCORE",
    "Khalid Nadaf Portfolio",
    "KHALIIDCORE Official Website",
    "video editor",
    "content creator",
    "reels editing",
    "digital branding",
  ],
  locale: "en_US",
  googleVerification: process.env.NEXT_PUBLIC_GOOGLE_SITE_VERIFICATION,

  links: {
    instagram: "https://www.instagram.com/khaliidcore",
    youtube: "https://www.youtube.com/@khaliidcore",
    // PLACEHOLDER: replace with your real email address
    email: "hello@example.com",
    // PLACEHOLDER: digits only with country code, e.g. 911234567890
    whatsapp: "910000000000",
  },
} as const;

export const nav = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Services", href: "#services" },
  { label: "Work", href: "#portfolio" },
  { label: "Skills", href: "#skills" },
  { label: "Milestones", href: "#achievements" },
  { label: "Contact", href: "#contact" },
] as const;

export const isPlaceholderEmail = site.links.email === "hello@example.com";
export const isPlaceholderWhatsapp = site.links.whatsapp === "910000000000";
