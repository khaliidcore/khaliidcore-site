import {
  Clapperboard,
  PenTool,
  Palette,
  Share2,
  Fingerprint,
  Code2,
  Film,
  Sparkles,
  Camera,
  Layers,
  Wand2,
  Cpu,
  type LucideIcon,
} from "lucide-react";

/* ------------------------------------------------------------------ */
/* SERVICES: offerings, not claims of past client work                  */
/* ------------------------------------------------------------------ */
export type Service = { title: string; description: string; icon: LucideIcon; points: string[] };

export const services: Service[] = [
  {
    title: "Video Editing",
    description:
      "Clean, story-first edits for reels, shorts and long-form video, paced for attention and polished for delivery.",
    icon: Clapperboard,
    points: ["Reels & Shorts", "Cinematic edits", "YouTube videos"],
  },
  {
    title: "Content Creation",
    description:
      "Ideas, scripts and formats that turn a topic into content people actually want to watch and share.",
    icon: PenTool,
    points: ["Concepts & scripting", "Informative content", "Series planning"],
  },
  {
    title: "Graphic Design",
    description: "Thumbnails, covers and visual assets that stay consistent across every platform.",
    icon: Palette,
    points: ["Thumbnails", "Social graphics", "Cover art"],
  },
  {
    title: "Social Media Content",
    description: "Platform-native content built around how Instagram and YouTube audiences really browse.",
    icon: Share2,
    points: ["Instagram", "YouTube", "Content calendars"],
  },
  {
    title: "Digital Branding",
    description: "A cohesive look and voice, from colour and type to tone, so a brand feels intentional.",
    icon: Fingerprint,
    points: ["Visual identity", "Tone of voice", "Brand consistency"],
  },
  {
    title: "Website Development",
    description: "Fast, responsive, accessible websites and portfolios built with modern web technology.",
    icon: Code2,
    points: ["Portfolio sites", "Landing pages", "SEO-ready builds"],
  },
];

/* ------------------------------------------------------------------ */
/* PORTFOLIO: edit this array to update the gallery.                    */
/*  - image: path inside /public (e.g. "/projects/my-edit.jpg")         */
/*  - video: optional short looping preview in /public (mp4/webm)       */
/*  - href:  link opened by "View Project" (YouTube/Instagram URL etc.) */
/* Entries below are PLACEHOLDERS. Replace with your real work.         */
/* ------------------------------------------------------------------ */
export type Project = {
  title: string;
  description: string;
  category: string;
  image?: string;
  video?: string;
  href: string;
  placeholder?: boolean;
};

export const projectCategories = ["All", "Short-form", "Long-form", "Design", "Web"] as const;

export const projects: Project[] = [
  {
    title: "Project Title 01",
    description: "Placeholder: describe the idea, your role and the result in one or two lines.",
    category: "Short-form",
    href: "https://www.instagram.com/khaliidcore",
    placeholder: true,
  },
  {
    title: "Project Title 02",
    description: "Placeholder: add a cinematic edit, with a preview image or looping video.",
    category: "Short-form",
    href: "https://www.instagram.com/khaliidcore",
    placeholder: true,
  },
  {
    title: "Project Title 03",
    description: "Placeholder: a long-form YouTube edit or storytelling project.",
    category: "Long-form",
    href: "https://www.youtube.com/@khaliidcore",
    placeholder: true,
  },
  {
    title: "Project Title 04",
    description: "Placeholder: technology or informative content series.",
    category: "Long-form",
    href: "https://www.youtube.com/@khaliidcore",
    placeholder: true,
  },
  {
    title: "Project Title 05",
    description: "Placeholder: thumbnail, cover or brand design work.",
    category: "Design",
    href: "https://www.khaliidcore.com",
    placeholder: true,
  },
  {
    title: "Project Title 06",
    description: "Placeholder: a website or web experience you built.",
    category: "Web",
    href: "https://www.khaliidcore.com",
    placeholder: true,
  },
];

/* ------------------------------------------------------------------ */
/* SKILLS: edit freely. level is 0-100 (visual indicator only).         */
/* ------------------------------------------------------------------ */
export type Skill = { name: string; note: string; level: number; icon: LucideIcon };

export const skills: Skill[] = [
  { name: "Reels & Shorts Editing", note: "Fast-paced vertical storytelling", level: 90, icon: Film },
  { name: "Cinematic Editing", note: "Mood, pacing and grade", level: 85, icon: Camera },
  { name: "Motion Graphics & FX", note: "Titles, transitions, effects", level: 80, icon: Sparkles },
  { name: "YouTube Editing", note: "Long-form structure & retention", level: 85, icon: Layers },
  { name: "Visual Storytelling", note: "Concept to final frame", level: 88, icon: Wand2 },
  { name: "Web Development", note: "Next.js, React, TypeScript", level: 60, icon: Cpu },
];

export const tools = [
  "Edit your tools here",
  "e.g. Premiere Pro",
  "e.g. After Effects",
  "e.g. DaVinci Resolve",
  "e.g. Photoshop",
  "e.g. Next.js",
];

/* ------------------------------------------------------------------ */
/* ACHIEVEMENTS: placeholders until you have real numbers.              */
/* Set `value` to a real figure (e.g. "10K+") and placeholder to false. */
/* ------------------------------------------------------------------ */
export type Milestone = { label: string; value: string; note: string; placeholder: boolean };

export const milestones: Milestone[] = [
  { label: "Videos edited", value: "00", note: "Add your real count", placeholder: true },
  { label: "Total views", value: "00", note: "Add your real figure", placeholder: true },
  { label: "Followers", value: "00", note: "Add your real figure", placeholder: true },
  { label: "Years creating", value: "00", note: "Add your real figure", placeholder: true },
];
